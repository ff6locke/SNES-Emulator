package com.example.snespocket

import android.app.Activity
import android.os.Bundle
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.content.Intent
import android.net.Uri
import android.view.ViewGroup
import android.graphics.Typeface

/**
 * SNES Pocket starter APK project.
 *
 * This is a front-end prototype, not yet a full SNES emulator. It provides a
 * landscape game screen, ROM file picker (.sfc/.smc), and touch controls.
 * CPU/PPU/APU emulation must be implemented or connected before ROMs can run.
 */
class MainActivity : Activity() {
    private lateinit var screen: GameScreen
    private val romPicker = 1001
    private var selectedRomName: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(12, 15, 28)
        window.navigationBarColor = Color.rgb(12, 15, 28)
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(12, 15, 28))
            setPadding(dp(12), dp(8), dp(12), dp(10))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = TextView(this).apply {
            text = "SNES POCKET"
            setTextColor(Color.WHITE)
            textSize = 20f
            typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
            letterSpacing = 0.12f
        }
        header.addView(title, LinearLayout.LayoutParams(0, dp(38), 1f))

        val loadButton = Button(this).apply {
            text = "LOAD ROM"
            setOnClickListener { chooseRom() }
        }
        header.addView(loadButton)
        root.addView(header)

        screen = GameScreen(this)
        root.addView(screen, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ).apply { topMargin = dp(5); bottomMargin = dp(8) })

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val dpad = DPadView(this)
        controls.addView(dpad, LinearLayout.LayoutParams(0, dp(118), 1.15f))
        val hint = TextView(this).apply {
            text = "Touch controls\nROM: .sfc / .smc\n\nEmulator core not yet connected"
            setTextColor(Color.rgb(174, 185, 210))
            textSize = 12f
            gravity = Gravity.CENTER
        }
        controls.addView(hint, LinearLayout.LayoutParams(0, dp(118), 1f))
        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        val topRow = LinearLayout(this).apply { gravity = Gravity.CENTER }
        listOf("Y", "X").forEach { label ->
            topRow.addView(actionButton(label), LinearLayout.LayoutParams(dp(52), dp(44)).apply {
                setMargins(dp(3), dp(2), dp(3), dp(2))
            })
        }
        val bottomRow = LinearLayout(this).apply { gravity = Gravity.CENTER }
        listOf("B", "A").forEach { label ->
            bottomRow.addView(actionButton(label), LinearLayout.LayoutParams(dp(52), dp(44)).apply {
                setMargins(dp(3), dp(2), dp(3), dp(2))
            })
        }
        buttons.addView(topRow)
        buttons.addView(bottomRow)
        controls.addView(buttons, LinearLayout.LayoutParams(0, dp(96), 1f))
        root.addView(controls)

        setContentView(root)
    }

    private fun actionButton(label: String): Button = Button(this).apply {
        text = label
        contentDescription = "SNES $label button"
        setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_DOWN) {
                screen.flashButton(label)
            }
            true
        }
    }

    private fun chooseRom() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf(
                "application/octet-stream", "application/x-snes-rom"
            ))
        }
        startActivityForResult(intent, romPicker)
    }

    @Deprecated("Legacy result API kept for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == romPicker && resultCode == RESULT_OK) {
            val uri: Uri = data?.data ?: return
            selectedRomName = uri.lastPathSegment?.substringAfterLast('/') ?: "Selected ROM"
            screen.romLabel = selectedRomName
            Toast.makeText(
                this,
                "ROM selected. A SNES emulation core is required to run it.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}

private class GameScreen(context: android.content.Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    var romLabel: String? = null
        set(value) { field = value; invalidate() }
    private var pressed = ""

    fun flashButton(label: String) {
        pressed = label
        invalidate()
        postDelayed({ pressed = ""; invalidate() }, 120)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.rgb(17, 22, 42))
        val w = width.toFloat()
        val h = height.toFloat()

        // Pixel-inspired placeholder scene.
        paint.color = Color.rgb(26, 39, 72)
        canvas.drawRoundRect(RectF(w * .03f, h * .07f, w * .97f, h * .93f), 14f, 14f, paint)
        paint.color = Color.rgb(59, 80, 128)
        canvas.drawRect(w * .08f, h * .16f, w * .92f, h * .20f, paint)
        paint.color = Color.rgb(104, 134, 196)
        canvas.drawRect(w * .12f, h * .25f, w * .25f, h * .29f, paint)
        canvas.drawRect(w * .75f, h * .33f, w * .88f, h * .37f, paint)

        paint.color = Color.rgb(47, 113, 95)
        canvas.drawRect(w * .08f, h * .68f, w * .92f, h * .82f, paint)
        paint.color = Color.rgb(85, 176, 116)
        canvas.drawRect(w * .08f, h * .68f, w * .92f, h * .72f, paint)

        paint.color = Color.rgb(255, 214, 112)
        canvas.drawRect(w * .47f, h * .43f, w * .53f, h * .55f, paint)
        canvas.drawRect(w * .44f, h * .46f, w * .56f, h * .52f, paint)
        paint.color = Color.rgb(22, 27, 48)
        canvas.drawRect(w * .48f, h * .46f, w * .49f, h * .48f, paint)
        canvas.drawRect(w * .51f, h * .46f, w * .52f, h * .48f, paint)

        paint.textAlign = Paint.Align.CENTER
        paint.typeface = Typeface.create("monospace", Typeface.BOLD)
        paint.textSize = (h * .075f).coerceIn(14f, 28f)
        paint.color = Color.WHITE
        canvas.drawText("SNES POCKET", w / 2f, h * .12f, paint)

        paint.typeface = Typeface.create("sans-serif", Typeface.NORMAL)
        paint.textSize = (h * .045f).coerceIn(10f, 18f)
        paint.color = Color.rgb(211, 220, 241)
        val line = if (romLabel == null) "READY FOR ROM" else "SELECTED: $romLabel"
        canvas.drawText(line.take(48), w / 2f, h * .89f, paint)
    }
}

private class DPadView(context: android.content.Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val unit = minOf(width / 3f, height / 3f)
        val cx = width / 2f
        val cy = height / 2f
        paint.color = Color.rgb(49, 58, 82)
        canvas.drawRoundRect(RectF(cx - unit * .48f, cy - unit * 1.42f,
            cx + unit * .48f, cy + unit * 1.42f), 9f, 9f, paint)
        canvas.drawRoundRect(RectF(cx - unit * 1.42f, cy - unit * .48f,
            cx + unit * 1.42f, cy + unit * .48f), 9f, 9f, paint)
        paint.color = Color.rgb(193, 204, 228)
        paint.textAlign = Paint.Align.CENTER
        paint.textSize = unit * .6f
        canvas.drawText("▲", cx, cy - unit * .72f, paint)
        canvas.drawText("▼", cx, cy + unit * 1.08f, paint)
        canvas.drawText("◀", cx - unit * .82f, cy + unit * .2f, paint)
        canvas.drawText("▶", cx + unit * .82f, cy + unit * .2f, paint)
    }
}
