# SNES Pocket (Android starter project)

This project builds an Android APK shell for a future SNES emulator.

## Current functionality
- Landscape Android app UI
- SNES-inspired placeholder game screen
- Touch D-pad and A/B/X/Y buttons (visual prototype)
- Android document picker for selecting `.sfc` / `.smc` files

## Important limitation
This is **not yet a working SNES emulator**. Selecting a ROM does not execute it. A compatible SNES emulation core must be implemented or integrated, including CPU (65C816), PPU, APU/SPC700/DSP, memory mapping, DMA/HDMA, and cartridge support.

## Build
Requirements: Android Studio, JDK 17, Android SDK Platform 35.

1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).

Or run:
```bash
gradle assembleDebug
```
The APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

Only use ROM dumps you are legally entitled to use.
