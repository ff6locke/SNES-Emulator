package com.nestv

import android.content.SharedPreferences
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.nio.IntBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

/** Values the GL thread reads every frame. */
class GfxParams {
    @Volatile var sharp = 1f
    @Volatile var scan = 0f
    @Volatile var mask = 0f
    @Volatile var curve = 0f
    @Volatile var blur = 0f
    @Volatile var vig = 0f
    @Volatile var aspect = 0   // 0 = 4:3, 1 = 8:7 pixel aspect, 2 = fill the screen
}

object GfxPresets {
    val NAMES = arrayOf("Sharp pixels", "Smooth", "Scanlines", "Scanlines + soft", "CRT TV", "Old composite TV")
    // sharp(0/1), scanlines, phosphor mask, curvature, blur, vignette  (0..100)
    val VALUES = arrayOf(
        intArrayOf(1, 0, 0, 0, 0, 0),
        intArrayOf(0, 0, 0, 0, 0, 0),
        intArrayOf(1, 55, 0, 0, 0, 0),
        intArrayOf(1, 45, 0, 0, 35, 10),
        intArrayOf(1, 55, 35, 40, 30, 45),
        intArrayOf(1, 35, 20, 30, 80, 60)
    )
    val ASPECTS = arrayOf("4:3 (TV)", "8:7 (pixel accurate)", "Fill screen")
}

/** Saved graphics options. Anything that changes calls onChange so the picture redraws immediately. */
class GfxSettings(private val prefs: SharedPreferences, private val p: GfxParams) {
    var preset = prefs.getInt("gfx_preset", 0)
    var sharp = prefs.getInt("gfx_sharp", 1)
    var scan = prefs.getInt("gfx_scan", 0)
    var mask = prefs.getInt("gfx_mask", 0)
    var curve = prefs.getInt("gfx_curve", 0)
    var blur = prefs.getInt("gfx_blur", 0)
    var vig = prefs.getInt("gfx_vig", 0)
    var aspect = prefs.getInt("gfx_aspect", 0)
    var showFps = prefs.getBoolean("gfx_fps", false)
    var onChange: () -> Unit = {}

    init { push() }

    fun push() {
        p.sharp = sharp.toFloat()
        p.scan = scan / 100f
        p.mask = mask / 100f
        p.curve = curve / 100f
        p.blur = blur / 100f
        p.vig = vig / 100f
        p.aspect = aspect
    }

    fun commit() {
        push()
        prefs.edit()
            .putInt("gfx_preset", preset).putInt("gfx_sharp", sharp).putInt("gfx_scan", scan)
            .putInt("gfx_mask", mask).putInt("gfx_curve", curve).putInt("gfx_blur", blur)
            .putInt("gfx_vig", vig).putInt("gfx_aspect", aspect).putBoolean("gfx_fps", showFps)
            .apply()
        onChange()
    }

    fun applyPreset(i: Int) {
        val v = GfxPresets.VALUES[i]
        preset = i
        sharp = v[0]; scan = v[1]; mask = v[2]; curve = v[3]; blur = v[4]; vig = v[5]
        commit()
    }

    /** Live preview while a slider moves: updates the picture but does not write to disk. */
    fun preview() {
        preset = GfxPresets.NAMES.size   // "custom"
        push()
        onChange()
    }

    fun snapshot() = intArrayOf(preset, sharp, scan, mask, curve, blur, vig)

    fun restore(s: IntArray) {
        preset = s[0]; sharp = s[1]; scan = s[2]; mask = s[3]; curve = s[4]; blur = s[5]; vig = s[6]
        commit()
    }

    fun presetName(): String = if (preset in GfxPresets.NAMES.indices) GfxPresets.NAMES[preset] else "Custom"
}

/**
 * Draws the 256x240 frame as a textured quad. The fragment shader does sharp-pixel scaling, scanlines,
 * a phosphor mask, screen curvature, horizontal blur and vignette, depending on GfxParams.
 */
class NesRenderer(
    private val p: GfxParams,
    private val fetch: (IntBuffer) -> Boolean
) : GLSurfaceView.Renderer {

    private var prog = 0
    private var tex = 0
    private var texValid = false
    private var sw = 1
    private var sh = 1
    private val buf: IntBuffer = ByteBuffer.allocateDirect(256 * 240 * 4).order(ByteOrder.nativeOrder()).asIntBuffer()
    private val quad: FloatBuffer = ByteBuffer.allocateDirect(16 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().also {
        it.put(floatArrayOf(-1f, 1f, 0f, 0f, 1f, 1f, 1f, 0f, -1f, -1f, 0f, 1f, 1f, -1f, 1f, 1f))
        it.position(0)
    }
    private var aPos = 0
    private var aUv = 0
    private var uTex = 0
    private var uTexSize = 0
    private var uOut = 0
    private var uSharp = 0
    private var uScan = 0
    private var uMask = 0
    private var uCurve = 0
    private var uBlur = 0
    private var uVig = 0

    private val vs = "attribute vec2 aPos; attribute vec2 aUV; varying vec2 vUV;" +
        "void main() { vUV = aUV; gl_Position = vec4(aPos, 0.0, 1.0); }"

    private val fsSimple = """
precision mediump float;
varying vec2 vUV;
uniform sampler2D uTex;
void main() { gl_FragColor = vec4(texture2D(uTex, vUV).bgr, 1.0); }
"""

    private val fs = """
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif
varying vec2 vUV;
uniform sampler2D uTex;
uniform vec2 uTexSize;
uniform vec2 uOut;
uniform float uSharp;
uniform float uScan;
uniform float uMask;
uniform float uCurve;
uniform float uBlur;
uniform float uVig;

vec3 tap(vec2 texel) { return texture2D(uTex, texel / uTexSize).bgr; }

void main() {
    vec2 uv = vUV;
    if (uCurve > 0.0) {
        vec2 dc = abs(0.5 - uv);
        dc *= dc;
        uv.x -= 0.5; uv.x *= 1.0 + dc.y * 0.3 * uCurve; uv.x += 0.5;
        uv.y -= 0.5; uv.y *= 1.0 + dc.x * 0.4 * uCurve; uv.y += 0.5;
    }
    vec2 texel = uv * uTexSize;
    vec2 fl = floor(texel);
    vec2 fr = texel - fl;
    vec2 sc = max(floor(uOut / uTexSize + 0.5), vec2(1.0));
    vec2 region = 0.5 - 0.5 / sc;
    vec2 cd = fr - 0.5;
    vec2 f = (cd - clamp(cd, -region, region)) * sc + 0.5;
    vec2 pos = mix(texel, fl + f, uSharp);
    vec3 col = tap(pos);
    if (uBlur > 0.0) {
        vec3 l = tap(pos - vec2(0.9, 0.0));
        vec3 r = tap(pos + vec2(0.9, 0.0));
        col = mix(col, 0.25 * l + 0.5 * col + 0.25 * r, uBlur);
    }
    if (uScan > 0.0) {
        float d = abs(fr.y - 0.5) * 2.0;
        col *= (1.0 - uScan * d * d) * (1.0 + uScan * 0.25);
    }
    if (uMask > 0.0) {
        float m = mod(gl_FragCoord.x, 3.0);
        vec3 mk = vec3(1.0 - uMask * 0.6);
        if (m < 1.0) mk.r = 1.0; else if (m < 2.0) mk.g = 1.0; else mk.b = 1.0;
        col *= mk * (1.0 + uMask * 0.4);
    }
    if (uVig > 0.0) {
        vec2 vc = vUV * 2.0 - 1.0;
        col *= 1.0 - uVig * 0.22 * dot(vc, vc);
    }
    vec2 e = smoothstep(vec2(0.0), vec2(0.004), uv) * smoothstep(vec2(0.0), vec2(0.004), 1.0 - uv);
    col *= e.x * e.y;
    gl_FragColor = vec4(clamp(col, 0.0, 1.0), 1.0);
}
"""

    private fun compile(type: Int, src: String): Int {
        val s = GLES20.glCreateShader(type)
        GLES20.glShaderSource(s, src)
        GLES20.glCompileShader(s)
        val ok = IntArray(1)
        GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) { GLES20.glDeleteShader(s); return 0 }
        return s
    }

    private fun build(vsrc: String, fsrc: String): Int {
        val v = compile(GLES20.GL_VERTEX_SHADER, vsrc)
        val f = compile(GLES20.GL_FRAGMENT_SHADER, fsrc)
        if (v == 0 || f == 0) return 0
        val pr = GLES20.glCreateProgram()
        GLES20.glAttachShader(pr, v)
        GLES20.glAttachShader(pr, f)
        GLES20.glLinkProgram(pr)
        val ok = IntArray(1)
        GLES20.glGetProgramiv(pr, GLES20.GL_LINK_STATUS, ok, 0)
        return if (ok[0] == 0) 0 else pr
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        prog = build(vs, fs)
        if (prog == 0) prog = build(vs, fsSimple)   // plain output if the full shader is not supported
        aPos = GLES20.glGetAttribLocation(prog, "aPos")
        aUv = GLES20.glGetAttribLocation(prog, "aUV")
        uTex = GLES20.glGetUniformLocation(prog, "uTex")
        uTexSize = GLES20.glGetUniformLocation(prog, "uTexSize")
        uOut = GLES20.glGetUniformLocation(prog, "uOut")
        uSharp = GLES20.glGetUniformLocation(prog, "uSharp")
        uScan = GLES20.glGetUniformLocation(prog, "uScan")
        uMask = GLES20.glGetUniformLocation(prog, "uMask")
        uCurve = GLES20.glGetUniformLocation(prog, "uCurve")
        uBlur = GLES20.glGetUniformLocation(prog, "uBlur")
        uVig = GLES20.glGetUniformLocation(prog, "uVig")

        val t = IntArray(1)
        GLES20.glGenTextures(1, t, 0)
        tex = t[0]
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, tex)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexImage2D(GLES20.GL_TEXTURE_2D, 0, GLES20.GL_RGBA, 256, 240, 0, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, null)
        texValid = false
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        sw = maxOf(width, 1)
        sh = maxOf(height, 1)
    }

    override fun onDrawFrame(gl: GL10?) {
        val fresh = fetch(buf)
        GLES20.glClearColor(0f, 0f, 0f, 1f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        if (prog == 0) return
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, tex)
        if (fresh || !texValid) {
            buf.position(0)
            GLES20.glTexSubImage2D(GLES20.GL_TEXTURE_2D, 0, 0, 0, 256, 240, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, buf)
            texValid = true
        }

        val ar = when (p.aspect) {
            0 -> 4f / 3f
            1 -> 256f * 8f / 7f / 240f
            else -> sw.toFloat() / sh.toFloat()
        }
        var vw = sw
        var vh = (sw / ar).toInt()
        if (vh > sh) { vh = sh; vw = (sh * ar).toInt() }
        GLES20.glViewport((sw - vw) / 2, (sh - vh) / 2, vw, vh)

        GLES20.glUseProgram(prog)
        quad.position(0)
        GLES20.glVertexAttribPointer(aPos, 2, GLES20.GL_FLOAT, false, 16, quad)
        GLES20.glEnableVertexAttribArray(aPos)
        quad.position(2)
        GLES20.glVertexAttribPointer(aUv, 2, GLES20.GL_FLOAT, false, 16, quad)
        GLES20.glEnableVertexAttribArray(aUv)
        GLES20.glUniform1i(uTex, 0)
        GLES20.glUniform2f(uTexSize, 256f, 240f)
        GLES20.glUniform2f(uOut, vw.toFloat(), vh.toFloat())
        GLES20.glUniform1f(uSharp, p.sharp)
        GLES20.glUniform1f(uScan, p.scan)
        GLES20.glUniform1f(uMask, p.mask)
        GLES20.glUniform1f(uCurve, p.curve)
        GLES20.glUniform1f(uBlur, p.blur)
        GLES20.glUniform1f(uVig, p.vig)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
    }
}
