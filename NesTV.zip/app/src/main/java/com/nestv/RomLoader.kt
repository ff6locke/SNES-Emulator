package com.nestv

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.ByteArrayInputStream
import java.io.File
import java.io.IOException
import java.util.zip.ZipInputStream

object RomLoader {
    fun fromFile(f: File): ByteArray = unwrap(f.readBytes())

    fun fromUri(ctx: Context, uri: Uri): ByteArray {
        val b = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() }
            ?: throw IOException("Cannot open file")
        return unwrap(b)
    }

    fun displayName(ctx: Context, uri: Uri): String {
        try {
            ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0 && c.moveToFirst()) return c.getString(i)
            }
        } catch (e: Exception) {}
        return uri.lastPathSegment ?: "rom"
    }

    /** Accepts a raw .nes or a .zip containing one. */
    private fun unwrap(b: ByteArray): ByteArray {
        if (b.size > 2 && b[0] == 'P'.code.toByte() && b[1] == 'K'.code.toByte()) {
            ZipInputStream(ByteArrayInputStream(b)).use { z ->
                var e = z.nextEntry
                while (e != null) {
                    if (e.name.endsWith(".nes", ignoreCase = true)) return z.readBytes()
                    e = z.nextEntry
                }
            }
            throw IOException("No .nes file inside the zip")
        }
        return b
    }
}
