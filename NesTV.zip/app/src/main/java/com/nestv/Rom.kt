package com.nestv

import java.util.Arrays

/** Parsed iNES / NES 2.0 image. mirror: 0 = vertical, 1 = horizontal, 2 = one-screen low, 3 = one-screen high. */
class Rom(data: ByteArray) {
    val prg: ByteArray
    val chr: ByteArray
    val chrRam: Boolean
    val mapperId: Int
    val submapper: Int
    val mirror: Int
    val battery: Boolean

    init {
        if (data.size < 16 || data[0] != 'N'.code.toByte() || data[1] != 'E'.code.toByte() ||
            data[2] != 'S'.code.toByte() || data[3] != 0x1A.toByte()
        ) throw IllegalArgumentException("Not an iNES ROM")

        val prgBanks = data[4].toInt() and 0xFF
        val chrBanks = data[5].toInt() and 0xFF
        val f6 = data[6].toInt() and 0xFF
        val f7 = data[7].toInt() and 0xFF
        var m = (f7 and 0xF0) or (f6 shr 4)
        var sub = 0
        if ((f7 and 0x0C) == 0x08) {
            m = m or ((data[8].toInt() and 0x0F) shl 8)
            sub = (data[8].toInt() and 0xFF) shr 4
        } else if (data[12].toInt() != 0 || data[13].toInt() != 0 || data[14].toInt() != 0 || data[15].toInt() != 0) {
            m = f6 shr 4 // dirty header
        }
        mapperId = m
        submapper = sub
        battery = (f6 and 2) != 0
        mirror = if ((f6 and 1) != 0) 0 else 1

        var off = 16 + (if ((f6 and 4) != 0) 512 else 0)
        val prgSize = maxOf(prgBanks, 1) * 16384
        prg = Arrays.copyOfRange(data, off, off + prgSize)
        off += prgSize
        chrRam = chrBanks == 0
        chr = if (chrRam) ByteArray(8192) else Arrays.copyOfRange(data, off, off + chrBanks * 8192)
    }
}
