package com.nestv

import android.content.Context
import android.os.Environment
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File

/** Tiny binary writer/reader used for save states. */
class SW {
    private val bo = ByteArrayOutputStream()
    private val o = DataOutputStream(bo)
    fun int(v: Int) = o.writeInt(v)
    fun bool(v: Boolean) = o.writeBoolean(v)
    fun float(v: Float) = o.writeFloat(v)
    fun bytes(a: ByteArray) = o.write(a)
    fun ints(a: IntArray) { for (x in a) o.writeInt(x) }
    fun result(): ByteArray { o.flush(); return bo.toByteArray() }
}

class SR(data: ByteArray) {
    private val i = DataInputStream(ByteArrayInputStream(data))
    fun int() = i.readInt()
    fun bool() = i.readBoolean()
    fun float() = i.readFloat()
    fun bytes(a: ByteArray) = i.readFully(a)
    fun ints(a: IntArray) { for (k in a.indices) a[k] = i.readInt() }
}

/**
 * Where battery saves and save states live. Several folders are used at once so that a copy survives
 * uninstalling the app: next to the ROM, /sdcard/NesTV/saves, and the app's private folder.
 */
object SaveStore {
    fun dirs(ctx: Context, romPath: String?): List<File> {
        val c = ArrayList<File>()
        if (romPath != null) {
            val p = File(romPath).parentFile
            if (p != null && !p.absolutePath.contains("/Android/data/")) c.add(File(p, "saves"))
        }
        @Suppress("DEPRECATION")
        val ext = Environment.getExternalStorageDirectory()
        c.add(File(ext, "NesTV/saves"))
        val internal = File(ctx.filesDir, "saves")
        c.add(internal)
        val ok = c.filter { usable(it) }
        return if (ok.isEmpty()) listOf(internal) else ok
    }

    private fun usable(d: File): Boolean {
        return try {
            if (!d.exists() && !d.mkdirs()) return false
            val t = File(d, ".w")
            t.writeText("x")
            t.delete()
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun newest(dirs: List<File>, name: String): File? =
        dirs.map { File(it, name) }.filter { it.isFile }.maxByOrNull { it.lastModified() }

    fun read(dirs: List<File>, name: String): ByteArray? =
        try { newest(dirs, name)?.readBytes() } catch (e: Exception) { null }

    fun modified(dirs: List<File>, name: String): Long? = newest(dirs, name)?.lastModified()

    fun writeAll(dirs: List<File>, name: String, data: ByteArray): Boolean {
        var any = false
        for (d in dirs) {
            try { File(d, name).writeBytes(data); any = true } catch (e: Exception) {}
        }
        return any
    }
}
