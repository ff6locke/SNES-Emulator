# Activities are kept automatically from the manifest. The emulator uses no reflection,
# so R8 is free to inline and optimise everything else.
